<?php

namespace App\Http\Controllers\Api\Super;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\Department\Models\Role;
use Modules\Department\Models\RoleToPermission;
use Illuminate\Support\Str;
use DB;
use Modules\Department\Models\Permission;
use App\Models\Super\AddOnPlanFeature;
use App\Models\Super\FeatureIndustry;
use Modules\Ecommerce\Models\Feature;

class AddOnPlanFeatureController extends Controller
{
    public $page = 'plan_feature';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

 

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        // get all request val
        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        // $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;



        $data_query = AddOnPlanFeature::query();
        
      //  PlanFeature::query();

        // search
        // if (!empty($search))
        //     $data_query = $data_query->where("feature_title", "LIKE", "%{$search}%");

        //  order by sorting

        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('sort_order', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;     // apply page logic

        $data_count = $data_query->count(); // get total count

        $data_list = $data_query->get();

            // if (!empty($data_list)) { 
            //     $data_list->map(function($data){

    

           
            //         $data->featureGroup = ($data->feature_group == 1) ?'Website':( ($data->feature_group == 2) ? 'Backend':'Marketing');
            //         return $data;
            //     });
            // }


           



        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $industry_ary = explode(',', $request->industry_id);


        $planfeature=AddOnPlanFeature::create([
            // 'industry_id'=>NULL,
            // 'feature_group'=>$request->feature_group,
            'feature_title'=>$request->feature_title,
            'feature_details'=>$request->feature_details,
            'sort_order'=>$request->sort_order,
          //  'status'=>$request->status,
      ]);        


        // $role->role_permissions()->attach($permissionList);

        if($planfeature) {
            return ApiHelper::JSON_RESPONSE(true,$planfeature,'SUCCESS_ADD_ON_PLAN_FEATURE_ADDED');
        }else{
            return ApiHelper::JSON_RESPONSE(false,[],'ERROR_ADD_ON_PLAN_FEATURE_ADDED');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

    //    $feature_list = PlanFeature::find($request->feature_id);

        $feature_list = AddOnPlanFeature::find($request->feature_id);

      
            //  select industry
            // $featIndu = $feature_list->feature_to_industry;
            // $selected_feature = [];
            // if (!empty($featIndu)) {
            //     foreach ($featIndu as $key => $cat) {
    
            //         $label_res = $cat->industry_details()->where('industry_id', $cat->industry_id)->first();
            //         $label = ($label_res !== null) ? $label_res->industry_name : '';
    
            //         array_push($selected_feature, [
            //             "label" => $label,
            //             "value" => $cat->industry_id,
            //         ]);
            //     }
            // }
            // $feature_list->selected_feature = $selected_feature;
            

        // $role_list->sections = ApiHelper::byRoleIdSectionsPermissionList($role_list->roles_id);
        return ApiHelper::JSON_RESPONSE(true, $feature_list, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */



    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $feature_id = $request->feature_id;
        $sort_order = $request->sort_order;

        $featureData =  AddOnPlanFeature::find($feature_id);
        $featureData->sort_order = $sort_order;
        $featureData->save();
      
        return ApiHelper::JSON_RESPONSE(true, $featureData, 'SUCCESS_SORT_ORDER_UPDATE');
    }



    public function update(Request $request)
    {
        $api_token = $request->api_token;

      

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $planfeature=AddOnPlanFeature::where('feature_id',$request->feature_id)->update([
            // 'industry_id'=>NULL,
            // 'feature_group'=>$request->feature_group,
            'feature_title'=>$request->feature_title,
            'feature_details'=>$request->feature_details,
            'sort_order'=>$request->sort_order,
            'status'=>$request->status,
      ]);  

     

    
        if ($planfeature)   return ApiHelper::JSON_RESPONSE(true, $planfeature,'ADD_ON_PLAN_FEATURE_UPDATED');
        else return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_UPDATE_ADD_ON_PLAN_FEATURE');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token; 
        $feature_id = $request->feature_id;

        $infoData = AddOnPlanFeature::find($feature_id);
        $infoData->status = ($infoData->status == 0) ? 1 : 0;
        $infoData->save();

       
        
        return ApiHelper::JSON_RESPONSE(true,$infoData,'SUCCESS_STATUS_UPDATE');
    }

}

