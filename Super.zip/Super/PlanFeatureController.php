<?php

namespace App\Http\Controllers\Api\Super;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\Department\Models\Role;
use Modules\Department\Models\RoleToPermission;
use Illuminate\Support\Str;
use DB;
use Modules\Department\Models\Permission;
use App\Models\Super\PlanFeature;
use App\Models\Super\FeatureIndustry;
use Modules\Ecommerce\Models\Feature;
use App\Models\Industry;

class PlanFeatureController extends Controller
{
    public $page = 'plan_feature';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';



    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        // get all request val
        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        // $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = PlanFeature::with('feature_to_industry.industry_details', 'feature_to_industry');


        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('sort_order', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;     // apply page logic

        $data_count = $data_query->count(); // get total count

        $data_list = $data_query->get();

        if (!empty($data_list)) {
            $data_list->map(function ($data) {

                $industryId = FeatureIndustry::where('feature_id', $data->feature_id)->first();
                $industryname = '';

                if (!empty($data->feature_to_industry)) {
                    foreach ($data->feature_to_industry as $featureIndusDetails) {
                        $industryname .= $featureIndusDetails->industry_details->industry_name;
                    }
                }

                $data->industry_name = explode(" ", $industryname);
                $data->featureGroup = ($data->feature_group == 1) ? 'Website' : (($data->feature_group == 2) ? 'Backend' : 'Marketing');
                return $data;
            });
        }


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $industry_ary = explode(',', $request->industry_id);
        $data = PlanFeature::max('sort_order');
        $sort_order = $data + 1;
        $planfeature = PlanFeature::create([
            'feature_group' => $request->feature_group,
            'feature_title' => $request->feature_title,
            'feature_details' => $request->feature_details,
            'sort_order' => $sort_order,
        ]);


        $feature_data = PlanFeature::where('feature_id', $planfeature['feature_id'])->first();
        $feature_industry = [];
        foreach ($industry_ary as $key => $value) {
            $feature_industry = FeatureIndustry::create([
                'feature_id' => $feature_data->feature_id,
                'industry_id' => $value,

            ]);
        }

        if ($planfeature) {
            return ApiHelper::JSON_RESPONSE(true, $planfeature, 'SUCCESS_PLAN_FEATURE_ADDED');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_PLAN_FEATURE_ADDED');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        $feature_list = PlanFeature::with('feature_to_industry.industry_details')->find($request->feature_id);
        //  select industry
        $featIndu = $feature_list->feature_to_industry;
        $selected_feature = [];
        if (!empty($featIndu)) {
            foreach ($featIndu as $key => $cat) {

                $label_res = $cat->industry_details()->where('industry_id', $cat->industry_id)->first();
                $label = ($label_res !== null) ? $label_res->industry_name : '';

                array_push($selected_feature, [
                    "label" => $label,
                    "value" => $cat->industry_id,
                ]);
            }
        }
        $feature_list->selected_feature = $selected_feature;
        $IndustryTypeList = Industry::select('industry_name as label', 'industry_id as value')->get();
        $res = [
            'data_list' => $feature_list,
            'IndustryTypeList' => $IndustryTypeList,
        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */



    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $feature_id = $request->feature_id;
        $sort_order = $request->sort_order;

        $featureData =  PlanFeature::find($feature_id);
        $featureData->sort_order = $sort_order;
        $featureData->save();

        return ApiHelper::JSON_RESPONSE(true, $featureData, 'SUCCESS_SORT_ORDER_UPDATE');
    }



    public function update(Request $request)
    {
        $api_token = $request->api_token;

        $industry_ary =  $request->industry_id;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $planfeature = PlanFeature::where('feature_id', $request->feature_id)->update([
            // 'industry_id'=>NULL,
            'feature_group' => $request->feature_group,
            'feature_title' => $request->feature_title,
            'feature_details' => $request->feature_details,
            'sort_order' => $request->sort_order,
            'status' => $request->status,
        ]);

        $feature_delete = FeatureIndustry::where('feature_id', $request->feature_id)->delete();

        $feature_industry = [];
        foreach ($industry_ary as $key => $value) {
            $feature_industry = FeatureIndustry::create([
                'feature_id' => $request->feature_id,
                'industry_id' => $value,

            ]);
        }

        if ($planfeature)   return ApiHelper::JSON_RESPONSE(true, $planfeature, 'PLAN_FEATURE_UPDATED');
        else return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_UPDATE_PLAN_FEATURE');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $feature_id = $request->feature_id;
        $sub_data = PlanFeature::find($feature_id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }
}
