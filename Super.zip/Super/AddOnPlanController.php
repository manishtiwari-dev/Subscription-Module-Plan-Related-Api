<?php

namespace App\Http\Controllers\Api\Super;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\Subscriber;
use App\Models\Subscription;
use App\Models\Super\AddOnPlan;
use App\Models\Super\AddOnPlanPrice;
use Illuminate\Http\Request;
use ApiHelper;
use App\Mail\StatusChangeMail;
use Illuminate\Support\Facades\Mail;
use App\Jobs\StatusUpdateMail;

class AddOnPlanController extends Controller
{
    public $page = 'adddon_plan';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';



    //This Function is used to show the list of plan
    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $current_page = !empty($request->page) ? $request->page : 1;
        //ApiHelper::perPageItem()
        $perPage = !empty($request->perPage) ? (int)$request->perPage : 10;
        $search = $request->search;
        $sortBy = $request->sortBy;
        $ASCTYPE = $request->orderBy;


        /*Fetching plan data*/
        $plan_query = AddOnPlan::query();
        /*Checking if search data is not empty*/
        if (!empty($search))
            $plan_query = $plan_query
                ->where("plan_name", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $plan_query = $plan_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $plan_query = $plan_query->orderBy('sort_order', 'ASC');
        }


        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;

        $plan_count = $plan_query->count();

        $plan_list = $plan_query->skip($skip)->take($perPage)->get();

        if (!empty($plan_list)) {
            $plan_list->map(function ($data) {
                $data->discount_type = ($data->discount_type == 0) ? 'No' : (($data->discount_type == 1) ? 'Fixed' : 'Percentage');
                return $data;
            });
        }


        /*Binding data into a variable*/
        $res = [
            'data' => $plan_list,
            'current_page' => $current_page,
            'total_records' => $plan_count,
            'total_page' => ceil((int)$plan_count / (int)$perPage),
            'per_page' => $perPage,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }
    //This Function is used to add the plan data
    public function add(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $plan_name = $request->plan_name;
        $plan_desc = $request->plan_desc;

        $validator = Validator::make($request->all(), [
            'plan_name' => 'required',

        ], [
            'plan_name.required' => 'PLAN_NAME_REQUIRED',

        ]);

        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }
        $data = AddOnPlan::create([
            'plan_name' => $plan_name,
            'plan_desc' => $plan_desc,
        ]);


        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_ADD_ON_PLAN_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_ADD_ON_PLAN_ADD');
        }
    }


    //This Function is used to show the particular plan data
    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }
        $plan_id = $request->plan_id;

        $data = AddOnPlan::where('plan_id', $plan_id)->first();

        return ApiHelper::JSON_RESPONSE(true, $data, '');
    }

    //This Function is used to update the particular plan data
    public function update(Request $request)
    {

        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        /*fetching data from api*/
        $plan_id = $request->plan_id;
        $plan_name = $request->plan_name;
        $plan_desc = $request->plan_desc;
        $status = $request->status;

        /*validating data*/
        $validator = Validator::make($request->all(), [
            'plan_name' => 'required',


        ], [
            'plan_name.required' => 'PLAN_NAME_REQUIRED',


        ]);
        /*if validation fails then it will show error message*/
        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());
        }
        /*updating plan data after validation*/
        $data = AddOnPlan::where('plan_id', $plan_id)->update([
            'plan_name' => $plan_name,
            'plan_desc' => $plan_desc,
            'status' => $status,
        ]);

        return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_ADD_ON_PLAN_UPDATE');
    }

    //This Function is used to get the change the plan status
    public function changeStatus(Request $request)
    {


        $api_token = $request->api_token;

        $plan_id = $request->plan_id;
        $sub_data = AddOnPlan::where('plan_id', $plan_id)->first();
        if ($sub_data->status == '1') {
            $data = AddOnPlan::where('plan_id', $plan_id)->update(['status' => '0']);
        } else {
            $data = AddOnPlan::where('plan_id', $plan_id)->update(['status' => '1']);
        }

        return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_STATUS_UPDATE');
    }



    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $plan_id = $request->plan_id;
        $sort_order = $request->sort_order;
        $infoData =  AddOnPlan::find($plan_id);
        if (empty($infoData)) {
            $infoData = new AddOnPlan();
            $infoData->plan_id = $plan_id;
            $infoData->sort_order = $sort_order;
            $infoData->status = 1;

            $infoData->save();
        } else {
            $infoData->sort_order = $sort_order;
            $infoData->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    }
}
