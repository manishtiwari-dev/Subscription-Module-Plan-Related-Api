<?php

namespace App\Http\Controllers\Api\Super;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Models\Super\WebsiteSettingGroupKey;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\Super\WebsiteSettingsGroup;

use App\Models\Currency;
use App\Models\Language;
use App\Models\Country;


class WebSettingGroupKeyController extends Controller
{
    public $page = 'website_key';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';




    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = WebsiteSettingGroupKey::select('setting_id', 'setting_key', 'setting_name', 'status', 'setting_options', 'option_type', 'sort_order')->where('group_id', $request->group_id);

        // search
        if (!empty($search))
            $data_query = $data_query->where("setting_name", "LIKE", "%{$search}%");

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('sort_order', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;     // apply page logic

        $data_count = $data_query->count(); // get total count
        $data_list = $data_query->skip($skip)->take($perPage)->get();
        $data_list = $data_query->get();


        if ($request->has('group_id')) {
            //getting category Name
            $grpName = WebsiteSettingsGroup::where('group_id', $request->group_id)->first();
            $cName = !empty($grpName) ? $grpName->group_name : '';
        }


        $res = [
            'data' => $data_list,
            'group_name' => $cName,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function create(Request $request)
    {
        $gName = '';
        $group_data = WebsiteSettingsGroup::all();
        if ($request->has('grpid')) {
            //getting category Name
            $select_group_data = WebsiteSettingsGroup::where('group_id', $request->grpid)->first();
            $gName = !empty($select_group_data) ? $select_group_data->group_name : '';
        }

        $res = [
            'data_list' => $group_data,
            'groupId' => $gName,

        ];

        if ($res)
            return ApiHelper::JSON_RESPONSE(true, $res, '');
        else
            return ApiHelper::JSON_RESPONSE(false, [], '');
    }



    public function store(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $validator = Validator::make($request->all(), [
            'group_id' => 'required',
            'setting_key' => 'required',
            'setting_name' => 'required',

        ], [
            'group_id.required' => 'GROUP_ID_REQUIRED',
            'setting_key.required' => 'SETTING_KEY_REQUIRED',
            'setting_name.required' => 'SETTING_NAME_REQUIRED',

        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $setting_data = $request->only('group_id', 'setting_key', 'setting_name', 'setting_options', 'option_type', 'setting_hint');

        $key_data =  WebsiteSettingGroupKey::max('sort_order');
        $sort_order = $key_data + 1;
        $setting_data['sort_order'] = $sort_order;
        $data = WebsiteSettingGroupKey::create($setting_data);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_APP_SETTINGS_KEY_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_APP_SETTINGS_KEY_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = WebsiteSettingGroupKey::where('setting_id', $request->setting_id)->first();
        $group_data = WebsiteSettingsGroup::all();
        $res = [
            'data_list' => $data_list,
            'group_data' => $group_data
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function update(Request $request)
    {

        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $validator = Validator::make($request->all(), [
            'group_id' => 'required',
            'setting_key' => 'required',
            'setting_name' => 'required',

        ], [
            'group_id.required' => 'GROUP_ID_REQUIRED',
            'setting_key.required' => 'SETTING_KEY_REQUIRED',
            'setting_name.required' => 'SETTING_NAME_REQUIRED',

        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $setting_update_data = $request->only('group_id', 'setting_key', 'setting_name', 'setting_options',  'option_type',  'setting_hint');
        $data = WebsiteSettingGroupKey::where('setting_id', $request->setting_id)->update($setting_update_data);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SETTING_GROUP_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SETTING_GROUP_UPDATE');
    }


    public function destroy(Request $request)
    {
        $api_token = $request->api_token;

        $status = WebsiteSettingGroupKey::where('setting_id', $request->setting_id)->delete();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_APP_SETTINGS_KEY_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_APP_SETTINGS_KEY_DELETE');
        }
    }
    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $setting_id = $request->setting_id;
        $sub_data = WebsiteSettingGroupKey::find($setting_id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }


    public function sortOrder(Request $request)
    {
        $api_token = $request->api_token;
        $setting_id = $request->setting_id;
        $sort_order = $request->sort_order;
        $infoData =  WebsiteSettingGroupKey::find($setting_id);
        if (empty($infoData)) {
            $infoData = new WebsiteSettingsGroup();
            $infoData->setting_id = $setting_id;
            $infoData->sort_order = $sort_order;
            $infoData->status = 1;

            $infoData->save();
        } else {
            $infoData->sort_order = $sort_order;
            $infoData->save();
        }

        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_SORT_ORDER_UPDATE');
    }
}
