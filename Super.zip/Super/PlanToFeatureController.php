<?php

namespace App\Http\Controllers\Api\Super;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\Industry;
use Modules\Department\Models\Role;
use Illuminate\Support\Str;
use DB;
use App\Models\Super\PlanFeature;
use App\Models\Super\PlanToFeature;


use App\Models\SubscriptionPlanToIndustry;
use App\Models\SubscriptionPlan;
use Modules\Ecommerce\Models\Feature;

class PlanToFeatureController extends Controller
{
    public $page = 'plan_to_feature';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageupdate = 'update';


    // sectionList 
    public function AllIndustryList(Request $request)
    {
        $api_token = $request->api_token;
        $language = $request->language;
        $planList = [];
        $usType = ($request->userType == 'administrator') ? 0 : 2;
        $utype = '1,' . $usType;
        $industryList = Industry::all();
        return ApiHelper::JSON_RESPONSE(true, $industryList, '');
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        // get all request val
        $language = $request->language;
        $usType = ($request->userType == 'administrator') ? 0 : 2;
        $utype = '1,' . $usType;

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $industry_id = $request->industry_id;


        //    $feature_query = PlanFeature::with('plan_to_feature');

        $feature_query = PlanFeature::with('plan_to_feature')->whereRelation('feature_to_industry', 'industry_id', $industry_id);

        $plan_data =  SubscriptionPlanToIndustry::with(['subscription_plan_details' => function ($query) {
            $query->orderBy('sort_order', 'ASC');
        }])->where('industry_id', $industry_id)->get();

        if (!empty($plan_data)) {
            $plan_data = $plan_data->map(function ($data) {

                $featureList = PlanToFeature::where('plan_id', $data->plan_id)->pluck('status', 'feature_id')->toArray();

                $featureLimit = PlanToFeature::where('plan_id', $data->plan_id)->pluck('feature_limit', 'feature_id')->toArray();

                $data->features = $featureList;
                $data->limits = $featureLimit;

                if (!empty($data->subscription_plan_details)) {
                    $data->subscription_plan_details = $data->subscription_plan_details()->orderBy('sort_order', 'ASC')->get();
                }


                return $data;
            });
        }



        // search
        if (!empty($search))
            $feature_query = $feature_query->where("feature_title", "LIKE", "%{$search}%");

        // order by sorting 
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $feature_query = $feature_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $feature_query = $feature_query->orderBy('sort_order', 'ASC');
        }

        $data_list = $feature_query->orderBy('sort_order', 'ASC')->get();


        if (!empty($data_list)) {
            $data_list = $data_list->map(function ($data) {

                $data->planIndu =
                    SubscriptionPlanToIndustry::all()->map(function ($planSec) use ($data) {

                        // filter record template_id, section_id
                        $planSec->featurDetails = PlanToFeature::where(
                            ['feature_id' => $data->feature_id, 'plan_id' => $planSec->plan_id]
                        )->get();

                        return $planSec;
                    });

                $data->featureGroup = ($data->feature_group == 1) ? 'Website' : (($data->feature_group == 2) ? 'Backend' : 'Marketing');

                return $data;
            });
        }



        $res = [
            'feature_list' => $data_list,
            'plan_data' => $plan_data,

        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $api_token = $request->api_token;


        $api_token = $request->api_token;

        $industry_list = Industry::all();



        $res = [


            'industry_list' => $industry_list,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $api_token = $request->api_token;
        $industry_id = $request->industry_id;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //  $plan_data=SubscriptionPlan::all();
        $feature_data = PlanFeature::all();
        $plan_data =  SubscriptionPlanToIndustry::all();

        $plantofeature = '';
        foreach ($plan_data as $planKey => $planVal) {
            foreach ($feature_data as $featKey => $featVal) {
                $plan_id = $planVal->plan_id;
                $feature_id = $featVal->feature_id;
                $feature_status = '';

                if (isset($request->{"status_" . $plan_id . "_" . $feature_id})) {
                    $feature_status = $request->{"status_" . $plan_id . "_" . $feature_id};
                    $feature_limit = $request->{"feature_limit_" . $plan_id . "_" . $feature_id};

                    $plantofeature = PlanToFeature::updateOrCreate(
                        ['plan_id' => $plan_id, 'feature_id' => $feature_id],
                        [
                            'status' => $feature_status,
                            'feature_limit' => $feature_limit
                        ]
                    );
                }
            }
        }



        if ($plantofeature) return ApiHelper::JSON_RESPONSE(true, $plantofeature, 'FEATURE_STATUS_CREATED');
        else return ApiHelper::JSON_RESPONSE(false, [], 'UNABLE_CREATE_FEATURE_STATUS');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }



    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $role_list = PlanFeature::with('planTofeature')->find($request->updateId);

        return ApiHelper::JSON_RESPONSE(true, $role_list, '');
    }
}
